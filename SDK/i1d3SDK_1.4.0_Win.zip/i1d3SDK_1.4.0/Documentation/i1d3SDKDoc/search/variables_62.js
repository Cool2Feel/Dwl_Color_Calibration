var searchData=
[
  ['b',['B',['../structi1d3_r_g_b__t.html#a1e18c6ec24b27062f3c10c2f53ffad5e',1,'i1d3RGB_t']]]
];
