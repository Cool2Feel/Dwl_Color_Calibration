//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by i1Display3Demo.rc
//
#define IDR_MAINFRAME                   101
#define IDD_I1DISPLAY3DEMO_DIALOG       1001
#define IDC_BUTTON_MEASURE_AIO          1002
#define IDC_BUTTON_MEASURE_AMBIENT      1003
#define IDC_BUTTON_MEASURE_BURST        1004
#define IDC_BUTTON_MEASURE_CRT          1005
#define IDC_BUTTON_MEASURE_LCD          1006
#define IDC_BUTTON_OPENCLOSE            1007
#define IDC_BUTTON_READ_DIFFUSOR_POS    1008
#define IDC_BUTTON_SET                  1009
#define IDC_BUTTON_MEASURE_BACKLIGHT_FREQ 1010
#define IDC_CAL_COMBO                   1011
#define IDC_EDIT_DEVICE_NUM             1012
#define IDC_EDIT_INTTIME_SECONDS        1013
#define IDC_EDIT_LED_OFF_TIME           1014
#define IDC_EDIT_LED_ON_TIME            1015
#define IDC_EDIT_LED_REPS               1016
#define IDC_EDIT_TARGET_TIME            1017
#define IDC_LOAD_CUSTOM_EDR             1018
#define IDC_MEAS_AMBIENT_L              1019
#define IDC_MEAS_AMBIENT_X              1020
#define IDC_MEAS_AMBIENT_Y              1021
#define IDC_MEAS_CAP_X                  1022
#define IDC_MEAS_CAP_Y                  1023
#define IDC_MEAS_CAP_Z                  1024
#define IDC_MEAS_L                      1025
#define IDC_MEAS_X                      1026
#define IDC_MEAS_Y                      1027
#define IDC_RADIO_FLASH                 1028
#define IDC_RADIO_OFF                   1029
#define IDC_RADIO_PULSE                 1030
#define IDC_STATIC_DIFFUSOR_POS         1031
#define IDC_STATIC_LED_SETTINGS         1032
#define IDC_STATIC_AIOMODE_SETTINGS     1033
#define IDC_STATIC_DISPLAY_BACKLIGHT_SYNC_LABEL 1034
#define IDC_DISPLAY_BACKLIGHT_SYNC      1035
#define IDC_STATIC_DISPLAY_BACKLIGHT_FREQ_LABEL 1036
#define IDC_DISPLAY_BACKLIGHT_FREQ      1037
#define IDC_STATIC_DISPLAY_REFRESH_RATE_LABEL 1038
#define IDC_DISPLAY_REFRESH_RATE        1039
#define IDC_EDIT_FIRMWARE_VER           1040

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         32785
#define _APS_NEXT_CONTROL_VALUE         1037
#define _APS_NEXT_SYMED_VALUE           105
#endif
#endif
