var searchData=
[
  ['r',['R',['../structi1d3_r_g_b__t.html#a559fa22119ff7827d75cb8ac9faccc3e',1,'i1d3RGB_t']]]
];
