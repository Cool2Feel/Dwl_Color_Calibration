var searchData=
[
  ['x',['x',['../structi1d3_yxy__t.html#ac81ec47e414dc292681bebf1cea09fff',1,'i1d3Yxy_t::x()'],['../structi1d3_x_y_z__t.html#ac679e5772a9db8db633558be3b9fe699',1,'i1d3XYZ_t::X()']]]
];
