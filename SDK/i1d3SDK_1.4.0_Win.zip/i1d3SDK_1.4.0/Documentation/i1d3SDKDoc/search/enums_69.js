var searchData=
[
  ['i1d3calibration_5fsource',['i1d3CALIBRATION_SOURCE',['../group__cir__types.html#gabd72202aa46d39e117449659bbde532e',1,'i1d3SDK.h']]],
  ['i1d3colorspace_5ft',['i1d3ColorSpace_t',['../group__meas__types.html#ga553536d860565b92d536818cc2afc9f0',1,'i1d3SDK.h']]],
  ['i1d3led_5fcontrol',['i1d3LED_Control',['../group__cir__types.html#gad41cab8d058e0e3ca5c6187ab10a694a',1,'i1d3SDK.h']]],
  ['i1d3lumunits_5ft',['i1d3LumUnits_t',['../group__meas__types.html#ga3490b7164aadc5b630a22468d60dd496',1,'i1d3SDK.h']]],
  ['i1d3measmode_5ft',['i1d3MeasMode_t',['../group__meas__types.html#gaf42ab6b72eb3c84676a83632084123d4',1,'i1d3SDK.h']]],
  ['i1d3status_5ft',['i1d3Status_t',['../group__cir__types.html#ga718166bbd49574f30aea4220d9b59451',1,'i1d3SDK.h']]]
];
