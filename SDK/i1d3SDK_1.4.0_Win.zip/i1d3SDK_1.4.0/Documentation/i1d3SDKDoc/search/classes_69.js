var searchData=
[
  ['i1d3calibration_5fentry',['i1d3CALIBRATION_ENTRY',['../structi1d3_c_a_l_i_b_r_a_t_i_o_n___e_n_t_r_y.html',1,'']]],
  ['i1d3calibration_5flist',['i1d3CALIBRATION_LIST',['../structi1d3_c_a_l_i_b_r_a_t_i_o_n___l_i_s_t.html',1,'']]],
  ['i1d3device_5finfo',['i1d3DEVICE_INFO',['../structi1d3_d_e_v_i_c_e___i_n_f_o.html',1,'']]],
  ['i1d3rgb_5ft',['i1d3RGB_t',['../structi1d3_r_g_b__t.html',1,'']]],
  ['i1d3xyz_5ft',['i1d3XYZ_t',['../structi1d3_x_y_z__t.html',1,'']]],
  ['i1d3yxy_5ft',['i1d3Yxy_t',['../structi1d3_yxy__t.html',1,'']]]
];
