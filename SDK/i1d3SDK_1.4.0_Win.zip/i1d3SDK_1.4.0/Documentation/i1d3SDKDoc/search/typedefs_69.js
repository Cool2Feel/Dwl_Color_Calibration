var searchData=
[
  ['i1d3handle',['i1d3Handle',['../group__cir__types.html#gae573accf5e26236a6c8797f57c476021',1,'i1d3SDK.h']]]
];
