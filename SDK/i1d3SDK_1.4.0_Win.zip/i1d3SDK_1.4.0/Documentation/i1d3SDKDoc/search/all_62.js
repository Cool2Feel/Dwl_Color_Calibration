var searchData=
[
  ['b',['B',['../structi1d3_r_g_b__t.html#a1e18c6ec24b27062f3c10c2f53ffad5e',1,'i1d3RGB_t']]],
  ['backlightsyncoff',['backlightSyncOff',['../group__cir__types.html#gga06fc87d81c62e9abb8790b6e5713c55ba884cedef10d43ea84d704c64a473cd3c',1,'i1d3SDK.h']]],
  ['backlightsyncon',['backlightSyncOn',['../group__cir__types.html#gga06fc87d81c62e9abb8790b6e5713c55ba7d77d57f0cdb98cf0d1359955b6dad05',1,'i1d3SDK.h']]]
];
