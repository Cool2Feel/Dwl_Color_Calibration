var searchData=
[
  ['max_5fbacklight_5ffreq',['MAX_BACKLIGHT_FREQ',['../group__cir__types.html#ga31bdc70c357085379c2aa9891a04e7ea',1,'i1d3SDK.h']]],
  ['max_5fi1d3calibration_5fentries',['MAX_I1D3CALIBRATION_ENTRIES',['../group__cir__types.html#ga8f37a15ca08afd22417b95b4041e05ed',1,'i1d3SDK.h']]],
  ['measurement_20header_20data_20types',['Measurement Header Data Types',['../group__meas__types.html',1,'']]]
];
